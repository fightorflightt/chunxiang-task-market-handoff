# Task Market Developer Handoff

本目录为返利 App 零工任务市场的开发评审交付包，版本 v0.2，日期 2026-10-13。

## 使用方式

打开 `dist/index.html`，查看低保真原型、页面需求、业务规则和验收用例。所有资源均保存在本目录内，无需联网。通过顶部入口及页面编号定位内容。

原型采用黑白灰线框。演示数据仅用于交互验证；预算、报酬、时限、账户和处理结果均为模拟，不连接真实交易服务。演示状态保存在浏览器内，可用重置按钮恢复。

## 目录

- `dist/index.html`：交付包统一入口。
- `dist/styles.css`：低保真布局。
- `dist/data.js`：页面需求、统一业务规则、验收用例、待确认事项。
- `dist/app.js`：导航、交互演示和打印导出。
- `docs/`：由同一份需求数据生成的文本交付文件。

## 评审边界

已明确的目标是雇主发布任务、零工领取并完成、验证通过后发放酬金并提现。权限、异常处理和首期流程为建议方案，需评审通过后生效。

具体任务内容、金额阈值、期限、收费政策、取消补偿、支付服务方案尚待确认。原型不代表生产实现，不包含接口设计或数据库方案。

已按用户要求部署到 GitHub Pages。在线评审入口：https://fightorflightt.github.io/chunxiang-task-market-handoff/ 。

仓库：https://github.com/fightorflightt/chunxiang-task-market-handoff 。采用独立仓库、main 分支根目录发布。在线内容公开可访问。

`github-pages/` 为独立发布仓库的本地副本；离线交付包只包含交付文件，不包含其 Git 记录。
